# Bundled resource attribution

EmbodiChain policy/configuration code: DexForce Technology Co., Ltd., Apache 2.0.
Assembly geometry is generated through mjfit by Younghyo Park, pinned revision
5833f465896e1e06bc4be4f003be847f5183a4db; MIT notice retained here.

The Flexiv Rizon 4S URDF and meshes use the official source revisions and
modifications recorded in Flexiv-NOTICE.txt. The full license is retained.
The ring visual is triangulated without changing its physical geometry.

The full mimic hand comes from the existing Robotiq2F85 dataset archive,
MD5 53ecbf2c953f43f1134aa7223e592292. Its existing provenance statement is
retained without inferring an upstream revision or asset-specific license.
The robot composition and run-owned paths are frozen for replay. The original
numerical parameters are those recorded in the URDF and fidelity.json.

No DexSim, Newton, MuJoCo or other SDK binary is included.
