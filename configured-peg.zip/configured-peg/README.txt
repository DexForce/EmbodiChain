Configuration-driven blind peg policy; ActorCritic + TemporalActor official_v1.
Random-start seed0; validation-selected update300 (39,321,600 transitions).
Final source: 7930/8192 (96.801758%); isolated wheel: 7933/8192 (96.838379%).
8192 balanced episodes,1024 arenas,seed20000,8 completions per arena.
Code: fb4ff20a87b6af835b2aa851d18cf2a609d67c44
Current full checkpoint schema and code are required; no legacy constructor.
Earlier reports and actual resource attribution/notices are retained.
SDK binaries are not included.
