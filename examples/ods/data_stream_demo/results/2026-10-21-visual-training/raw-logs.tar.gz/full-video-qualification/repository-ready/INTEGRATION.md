# Post-timing full video integrity integration

The repository-ready candidate is `video_integrity.py`. Its public entry point is
`verify_dataset(root, output, *, ffmpeg=None, ffprobe=None, threads=1, timeout=600.0)`.
It is pinned by the SHA256 in `qualified-final-k5pqki1u/qualification.json`.

## Existing frozen 30-run experiment

1. Wait until every timed training process has finished; add no new full-video
   reads while formal generation/recording is active.
2. Copy the candidate to `examples/ods/data_stream_demo/video_integrity.py` and
   record its exact source SHA256 as a **new audit revision**. Keep each run's
   original source snapshots, `environment.json`, training receipt and all
   timing/update counts unchanged.
3. For every completed corpus, run the new module on CPU with one decoder thread,
   one file at a time and an inherited affinity bounded to eight CPU cores. Save
   a new `full-video-integrity-v1.json` plus its new sibling artifact directory;
   never overwrite the existing `post-audit.json` or failed attempts.
4. Require the original training and H2/source audit to pass **and** the new
   receipt to contain `passed=true`, `all_saved_video_frames_decoded=true`, exact
   per-camera official frame totals, matching corpus path and the expected
   verifier SHA. Treat failed or unavailable full integrity as unqualified for
   the strengthened final report; retain failures without replacing seeds.
5. Generate a new report revision that points to both receipts. Report full
   decode time separately as `seconds_outside_training_pipeline`; leave the
   measured pipeline `T_final` and the original source/version inputs intact.

A successful full scan establishes software decoding/count integrity for every
saved AV1 frame, including untrained tails. Frame hashes cover decoded **YUV420p
rawvideo planes**, not RGB/normalized policy inputs. Keep the existing SDK H2
checks for representative timestamp/format compatibility and sparse RGB
PSNR/MAE checks. This does not prove lossless RGB fidelity, all SDK seek positions
or policy quality.

## Future `training_audit` revision

- Add the `verify_dataset` call after numeric/work/checkpoint checks and SDK
  representative decoding, and qualify only if its full-video receipt passes.
- Give the combined receipt an explicit new audit revision and include the new
  module SHA, full-video receipt path and file/camera frame counts.
- Thread the chosen receipt path into `audit_run` itself. The current CLI's
  `--output` only copies a result **after** `audit_run` writes `post-audit.json`;
  do not use that behavior to backfill an older run. Make both receipt and
  full-video artifact paths exclusive so retries preserve prior evidence.
- For new runs, the supervisor may continue to expect the default
  `post-audit.json` filename, now carrying the new revision. For historical
  backfills, use explicitly new output names; do not regenerate original
  training metadata under the new source version.
- If an audit implementation is corrected, create a new revision/attempt path,
  retain the old failed receipt and keep input compressed/metadata hashes to
  distinguish audit changes from changed corpora.
