# Superseded diagnostic matrix

This matrix was stopped after an independent review found unnecessary recorder-submission barriers before refill in the offline and serial controls. Those barriers confound timing and overlap attribution. The four completed runs, cancellation failures, all not-started cells and original reports remain unchanged as diagnostic evidence. Do not use this matrix for final comparative efficiency claims. A new protocol revision will regenerate every group after the scheduling fix; no seed or timing outcome is selected away.
