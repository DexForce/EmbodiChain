# ODS visual training: fixed-work time and diversity

Qualified runs: **4/30**; qualified formal pairs: **3**. Failed, unsupported and unqualified runs remain in report.json and are excluded from aggregate values and paired time ratios.

Each result completes the declared optimizer-update, batch and valid-target budget. Data amount and final coverage may differ. Ratios compare total pipeline time, including acquisition, recording, decode, actual training, checkpoint and normal teardown; they do not establish equal policy quality or a universal ODS speedup.

## single

Values are median [minimum, maximum] across qualified seeds.

| Path | n | Total s | Trained sources | Effective sources | XY cells / 64 | Unique targets |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Offline-8 | 1 | 142 [142, 142] | 8 [8, 8] | 8 [8, 8] | 7 [7, 7] | 3.91e+03 [3.91e+03, 3.91e+03] |
| Offline-32 | 1 | 413 [413, 413] | 32 [32, 32] | 32 [32, 32] | 27 [27, 27] | 1.57e+04 [1.57e+04, 1.57e+04] |
| Offline-128 | 1 | 1.51e+03 [1.51e+03, 1.51e+03] | 128 [128, 128] | 128 [128, 128] | 56 [56, 56] | 5.54e+04 [5.54e+04, 5.54e+04] |
| ODS overlap | 1 | 393 [393, 393] | 32 [32, 32] | 32 [32, 32] | 27 [27, 27] | 1.57e+04 [1.57e+04, 1.57e+04] |
| ODS serial replay | 0 | — | — | — | — | — |

| Baseline / ODS overlap | Paired seeds | Total-time ratio median [min, max] |
| --- | ---: | ---: |
| Offline-8 | 1 | 0.361 [0.361, 0.361] |
| Offline-32 | 1 | 1.05 [1.05, 1.05] |
| Offline-128 | 1 | 3.83 [3.83, 3.83] |
| ODS serial replay | 0 | — |

| Path | CPU mean / assigned capacity % | Simulation GPU board mean % | Training GPU board mean % |
| --- | ---: | ---: | ---: |
| Offline-8 | 46.5 [46.5, 46.5] | 18.3 [18.3, 18.3] | 1.84 [1.84, 1.84] |
| Offline-32 | 51.3 [51.3, 51.3] | 26.2 [26.2, 26.2] | 0.855 [0.855, 0.855] |
| Offline-128 | 53.3 [53.3, 53.3] | 29.1 [29.1, 29.1] | 0.307 [0.307, 0.307] |
| ODS overlap | 56.2 [56.2, 56.2] | 34.8 [34.8, 34.8] | 1.47 [1.47, 1.47] |
| ODS serial replay | — | — | — |

CPU values use continuing-PID sampled interval deltas normalized by the assigned cores; new or disappeared processes may be undercounted. GPU values are whole-board NVML samples and include foreign work; they do not attribute kernel utilization to this run. Missing observations remain unknown (—), not zero. See raw resources for sample counts and process-coverage gaps.

## dual

Values are median [minimum, maximum] across qualified seeds.

| Path | n | Total s | Trained sources | Effective sources | XY cells / 64 | Unique targets |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Offline-8 | 0 | — | — | — | — | — |
| Offline-32 | 0 | — | — | — | — | — |
| Offline-128 | 0 | — | — | — | — | — |
| ODS overlap | 0 | — | — | — | — | — |
| ODS serial replay | 0 | — | — | — | — | — |

| Baseline / ODS overlap | Paired seeds | Total-time ratio median [min, max] |
| --- | ---: | ---: |
| Offline-8 | 0 | — |
| Offline-32 | 0 | — |
| Offline-128 | 0 | — |
| ODS serial replay | 0 | — |

| Path | CPU mean / assigned capacity % | Simulation GPU board mean % | Training GPU board mean % |
| --- | ---: | ---: | ---: |
| Offline-8 | — | — | — |
| Offline-32 | — | — | — |
| Offline-128 | — | — | — |
| ODS overlap | — | — | — |
| ODS serial replay | — | — | — |

CPU values use continuing-PID sampled interval deltas normalized by the assigned cores; new or disappeared processes may be undercounted. GPU values are whole-board NVML samples and include foreign work; they do not attribute kernel utilization to this run. Missing observations remain unknown (—), not zero. See raw resources for sample counts and process-coverage gaps.

## Figures and interpretation

![End-to-end time and actual trained-state coverage](01_time_diversity.png)

![Coverage after completed optimizer updates](02_coverage_growth.png)

![Measured pipeline stages](03_pipeline_timeline.png)

![Lifetime source reuse, including retired sources](04_lifetime_reuse.png)

Coverage uses completed training only. Initial XY bins are fixed 1 cm cells over the task's 8 cm × 8 cm reset area; anchor-state voxels are 2 cm. Source identity growth alone is not physical diversity. Overlapping prediction windows share target frames and are deduplicated by immutable frame identity. Published but untrained data does not increase these metrics.

AV1 decoding is lossy. Compare source quality audits and held-out evaluation alongside timing. Differences between online raw pixels and decoded pixels prevent a claim of identical optimization trajectories. Serial trace replay isolates overlap only when its source/anchor manifest audit passes. A faster small offline run or broader large offline corpus is a valid result.

Intervals may overlap and are not summed into total time. Timeline rows use the first observed qualified seed per vision, without selecting the fastest run. PNG, SVG and PDF versions share measured inputs.

Formal ratios require matching initial-model/normalization SHA256, initial-C numeric prefix, camera order, declared/completed training budget, ordered primary GPU UUIDs and the same eight CPU cores. Retained supervisor launch masks/thread limits, placement guards, process exit and clocks must agree. Missing evidence blocks claims; smoke/calibration or legacy CPU rendering fixtures are not formal comparisons. Post-timing corpus audit and evaluation durations are excluded from pipeline time.

## Excluded paired claims

- single / ods_serial / seed 19001: requires exactly one qualified run per arm and seed.

## Retained unqualified runs

- `/tmp/ods-visual-training-formal-20261021-v2/ods_overlap/dual/seed19001/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_overlap/dual/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_overlap/dual/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_serial/dual/seed19001/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_serial/dual/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_serial/dual/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline128/dual/seed19001/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline128/dual/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline128/dual/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline32/dual/seed19001/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline32/dual/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline32/dual/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline8/dual/seed19001/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline8/dual/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline8/dual/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_overlap/single/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_overlap/single/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_serial/single/seed19001/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_serial/single/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/ods_serial/single/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline128/single/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline128/single/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline32/single/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline32/single/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline8/single/seed19002/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
- `/tmp/ods-visual-training-formal-20261021-v2/offline8/single/seed19003/summary.json`: status=failed, no explicit qualification pass, missing positive training budget, invalid completion timing, source totals disagree with completed work, training cap audit absent or failed.
