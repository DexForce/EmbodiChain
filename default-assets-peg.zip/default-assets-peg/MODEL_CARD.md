# Default-asset blind peg policy

This is the unchanged validation-selected native PPO checkpoint (update 850) from the earlier 1000-update default-asset run, packaged for the split implementation. It is not an author-provided policy.

The current code replay scores **7275/8192 = 88.8062%**, Wilson 95% interval **88.1051–89.4708%**. The fixed protocol uses 1024 arenas, 8 scored completions per arena, seed 20000 and deterministic policy means. Historical assessment: 7240/8192 = 88.3789%. These are regression replays of a previously selected checkpoint; do not use the test to select new weights.

The 95% engineering target remains unmet. One training seed and one geometry do not establish paper reproduction, OOD performance or real-device performance. Solver iteration-budget and SDK teardown warnings remain explicit in the logs. The new SDK MR is not the historical qualification profile.

The native DexSim preview retains seeds 30000, 30001, 30002 in order (3/3 completed successfully). The relocated installed wheel scores **7288/8192 = 88.9648%**, Wilson 95% interval **88.2680–89.6252%**, under the same full protocol. The preceding 64-arena smoke scored 42/64 versus source 46/64; those small-sample results are retained and are not trajectory-equivalence evidence. A separate random-initialization 16-arena, 2-update training run produced a finite checkpoint; the full 1000-update training was not repeated during this split.

See `evidence/split_replay_20261105/reproduction.json` and its raw reports/logs. Earlier training lineage and resource attribution remain in `evidence/` and `licenses/`. SDK binaries are not redistributed.
