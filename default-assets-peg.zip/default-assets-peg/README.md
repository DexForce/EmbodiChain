# Native default-asset blind peg replay

Install the final split PR and the historical runtime profile documented by `examples/learning/blind_assembly/REPRODUCING.md`. Set `RUN` to this extracted directory. No mjfit installation or generation is required to replay the bundled robot, geometry and policy.

```bash
embodichain eval-policy "$RUN" --checkpoint best --episodes 8192 --num-envs 1024 --seed 20000 --episode-allocation balanced --renderer no-render
DISPLAY=:1 embodichain run-example learning/blind_assembly/preview "$RUN" --checkpoint best --episodes 3 --seed 30000 --output outputs/assembly_preview
```

Expected development result: approximately 88–89% under the recorded profile, not the 95% target. Contact solves and parallel arena scheduling do not promise bitwise-identical trajectories. The 64-episode/64-arena wheel smoke is a separate small-sample protocol (42/64 versus source 46/64), not a bitwise-equivalence check.

`configs/train.yaml` is a portable fresh-training recipe against the same frozen physical resources. Its 4096-arena, 1000-update budget is the historical development experiment. It starts from random weights when used with `train-rl --config`; no resume is implied. Complete retraining was not repeated for the split. `exports/actor.pt` is the existing actor-only export including normalization; task managers own history and action semantics.

Read `MODEL_CARD.md` for measurements and limitations. `file_manifest.json` covers all other bundle files; preserve the robot and gripper attribution in `licenses/` and physical resources. The proprietary SDK is deliberately absent.
