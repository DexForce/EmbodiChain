# Generative Simulation - Task Engine

Open `index.html` in a desktop or mobile browser. The two previews use the original Chinese instructions and source images from [DexForceAI/embodichain_data, revision dcb448da](https://huggingface.co/datasets/DexForceAI/embodichain_data/tree/dcb448da52ea3df5df5a249e9ff977acafead0e4/gen_sim_assets). The English instructions come from the same dataset revision.

These are interactive design-review materials for DexForce/EmbodiChain#1279. The plans were published with the hybrid route at engine commit `a4eca8be445b54136dec0adb33123f3afa712734`. The preview reflects a later design iteration on those saved plans. Both use fixed responses for offline replay. The online model returned HTTP 401 before planning. Physical execution and goal acceptance were not evaluated.

| Case | Replay input | Published result |
| --- | --- | --- |
| task1186 | Repository fruit-handover fixture and its four reviewed image boxes | Seven calls, ready for scene qualification |
| task1182 | Fixed operation declarations authored from the original instruction | Nine calls, authoring only |

Switch samples, language and theme in the header. In the dependency view select a node to inspect its actual Semantic Call and parameters. For task1186, the shared lane distinguishes handover direction from simultaneous two-arm transport. Selecting a role highlights its related calls. Choose a completion criterion to locate its producing call and phase. Task Spec opens the frozen specification. Export provides the graph or specification as JSON and the dependency diagram as SVG.

The `cases/` folders include the source PNGs and selected published JSON files, including the frozen Task Spec, canonical graph, coverage and fixed responses. Their contents were checked against the original plan manifests. The three display stages in each example group canonical calls for this preview. The archived graph preserves its original task group.

The editable display template, styles, script and embedded display data are in `source/`. The standalone viewer includes the six Lucide icons it uses and runs offline.
