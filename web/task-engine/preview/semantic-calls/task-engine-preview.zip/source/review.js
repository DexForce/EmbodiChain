(() => {
  const root = document.getElementById("te-review-redesign");
  const samples = JSON.parse(document.getElementById("te-review-inputs").textContent);
  const ui = id => root.querySelector("#te-" + id);
  const states = Object.fromEntries(Object.keys(samples).map(id => [id, {
    openStage: 0, role: null, call: null, inferred: false, goal: null
  }]));
  let caseId = "task1186";
  let view = "engineering";
  Object.assign(states.task1186, { openStage: 0, call: "call_1" });
  let language = "zh", theme = "system";
  const t = (zh, en) => language === "en" ? en : zh;
  const labels = {
    "双臂交接与搬盘":"Dual-arm handover and plate transport","量杯倾倒与收纳":"Pouring and storing the measuring cup",
    "苹果":"Apple","橙子":"Orange","盘子":"Plate","中央服务垫":"Serving mat","量杯":"Measuring cup","白碗":"White bowl","备餐托盘":"Prep tray","灰色杯垫":"Gray coaster",
    "右臂递苹果，左臂放入盘中":"Hand over the apple and place it on the plate",
    "右臂递橙子，左臂放入同一盘子":"Hand over the orange and use the same plate",
    "双臂将果盘搬到中央服务垫":"Carry the fruit plate to the serving mat",
    "朝白碗做倾倒动作，量杯归位":"Pour toward the bowl and return the cup",
    "将白碗放入备餐托盘":"Put the white bowl in the prep tray","将量杯放到灰色杯垫":"Put the measuring cup on the gray coaster",
    "右臂拿起苹果":"Pick up the apple with the right arm","右臂将苹果递给左臂":"Pass the apple from right to left",
    "左臂将苹果放入盘子并松开":"Place and release the apple with the left arm",
    "右臂拿起橙子":"Pick up the orange with the right arm","右臂将橙子递给左臂":"Pass the orange from right to left",
    "左臂将橙子放入盘子并松开":"Place and release the orange with the left arm",
    "双臂将盘子搬到中央服务垫并放下":"Carry the plate with both arms and set it on the serving mat",
    "拿起量杯":"Pick up the measuring cup","将量杯移向白碗":"Move the cup toward the white bowl",
    "量杯朝白碗做一次倾倒动作":"Make one pouring motion toward the bowl","持量杯移回原位":"Move the held cup back to its starting position",
    "量杯放回原位并松开":"Set the cup back in place and release it","拿起白碗":"Pick up the white bowl",
    "将白碗放入备餐托盘并松开":"Place the bowl in the prep tray and release it","再次拿起量杯":"Pick up the measuring cup again",
    "将量杯放到灰色杯垫并松开":"Place the cup on the gray coaster and release it",
    "苹果从右臂交给左臂":"Apple transferred from right to left","苹果在盘中（左臂放入）":"Apple on the plate, placed by the left arm",
    "橙子从右臂交给左臂":"Orange transferred from right to left","橙子在盘中（左臂放入）":"Orange on the plate, placed by the left arm",
    "双臂共同持有盘子":"Both arms hold the plate","盘子在中央服务垫上":"Plate on the central serving mat",
    "量杯朝白碗完成一次倾倒动作":"One pouring motion from the cup toward the bowl","白碗在备餐托盘内":"White bowl in the prep tray",
    "量杯在灰色杯垫上":"Measuring cup on the gray coaster"
  };
  const label = s => {
    if (!(s in labels)) throw new Error("Missing display label: " + s);
    return labels[s];
  };
  const english = Object.fromEntries(Object.entries(samples).map(([id,d]) => [id, {
    ...d, title:label(d.title),
    roles:Object.fromEntries(Object.entries(d.roles).map(([key,name]) => [key,label(name)])),
    stages:d.stages.map(s => ({...s,label:label(s.label)})),
    goals:d.goals.map(g => ({...g,label:label(g.label)})),
    actions:Object.fromEntries(Object.entries(d.actions).map(([key,a]) => [key,{
      ...a,label:label(a.label),checks:a.checks.map(c=>({...c,label:label(c.label)}))
    }]))
  }]));
  const chrome = {
    "步骤列表":"Steps","依赖图":"Dependencies",
    "样例":"Sample","语言":"Language","主题":"Theme","跟随系统":"System","浅色":"Light","深色":"Dark",
    "固定响应回放":"Offline replay","计划覆盖":"Plan coverage","场景":"Scene","执行":"Execution","未执行":"Not run",
    "工程依赖":"Dependencies","导出":"Export","任务流程":"Task flow","输入场景":"Source scene","放大":"Enlarge",
    "任务对象":"Task objects","原始指令":"Dataset instruction","完成条件":"Completion criteria",
    "待执行评估":"Awaiting execution","调用依赖":"Call dependencies","关闭":"Close","导出任务图":"Export task graph",
    "格式":"Format","任务图 JSON":"Task graph JSON","依赖图 SVG":"Dependency graph SVG",
    "Task Engine 任务审阅":"Task Engine review","界面语言":"Interface language","界面主题":"Interface theme","切换任务样例":"Select sample",
    "计划和执行状态":"Plan and execution status","查看方式":"View","按任务对象定位动作":"Locate actions by object",
    "语义调用及依赖，选择节点查看参数":"Semantic calls and dependencies. Select a node to inspect its parameters.",
    "所选调用":"Selected call","导出内容":"Export contents"
  };
  const chromeText = [], chromeAttrs = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const n = walker.currentNode, value = n.data.trim();
    if (Object.hasOwn(chrome,value)) chromeText.push([n,n.data,n.data.replace(value,chrome[value])]);
  }
  for (const n of [root,...root.querySelectorAll("[aria-label]")]) {
    const original=n.getAttribute("aria-label");
    if (Object.hasOwn(chrome,original)) chromeAttrs.push([n,original,chrome[original]]);
  }
  function preferences() {
    root.lang = t("zh-CN","en");
    root.dataset.theme = theme;
    ui("language").value = language;
    ui("theme").value = theme;
    for (const [n,zh,en] of chromeText) n.data = t(zh,en);
    for (const [n,zh,en] of chromeAttrs) n.setAttribute("aria-label",t(zh,en));
  }
  let lastBoardWidth = 0;
  const phaseName = phase => ({ terminal:t("动作结束时","at step end"), acquire:t("抓稳时","on grasp"), release:t("放下时","on release") })[phase];
  const armName = arm => arm === "left" ? t("左臂","left arm") : t("右臂","right arm");
  const sample = () => (language === "en" ? english : samples)[caseId];
  const state = () => states[caseId];

  function el(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function button(command, key, className, text) {
    const control = el("button", className, text);
    control.type = "button";
    control.dataset.command = command;
    control.dataset.key = key;
    control.dataset.focus = command + "/" + key;
    return control;
  }

  function icon(name) {
    const mark = el("i");
    mark.setAttribute("data-lucide", name);
    mark.setAttribute("aria-hidden", "true");
    return mark;
  }

  function refreshIcons() {
    if (window.lucide && typeof window.lucide.createIcons === "function") {
      window.lucide.createIcons({ attrs: { width: 16, height: 16, "aria-hidden": "true" } });
    }
  }

  function forCall(uid) {
    return sample().graph.nodes.find(n => n.id === uid);
  }

  function stageIndex(uid) {
    return sample().stages.findIndex(s => s.calls.includes(uid));
  }

  function directlyRelated(uid) {
    return !!state().role && sample().actions[uid].roles.includes(state().role);
  }

  function restore(snapshot) {
    const saved = snapshot?.privateContent?.taskEngineReview;
    if (saved?.revision !== 1 || !Object.hasOwn(samples, saved.caseId)) return false;
    caseId = saved.caseId;
    language = saved.language === "en" ? "en" : "zh";
    theme = ["light","dark"].includes(saved.theme) ? saved.theme : "system";
    view = saved.view === "engineering" ? "engineering" : "review";
    for (const [id, data] of Object.entries(samples)) {
      const entry = saved.cases?.[id];
      if (!entry) continue;
      const s = states[id];
      s.openStage = Number.isInteger(entry.openStage) && entry.openStage >= -1 &&
        entry.openStage < data.stages.length ? entry.openStage : 0;
      s.role = Object.hasOwn(data.roles, entry.role) ? entry.role : null;
      s.call = Object.hasOwn(data.actions, entry.call) ? entry.call : null;
      s.inferred = !!s.call && entry.inferred === true;
      if (s.role && (!s.call || !data.actions[s.call].roles.includes(s.role))) {
        const matches = data.graph.nodes.filter(n => data.actions[n.id].roles.includes(s.role));
        s.call = matches.length === 1 ? matches[0].id : null;
        s.inferred = !!s.call;
        if (s.call) s.openStage = data.stages.findIndex(g => g.calls.includes(s.call));
      }
      s.goal = data.goals.some(g => g.id === entry.goal && g.call === s.call) ? entry.goal : null;
    }
    return true;
  }

  function save() {
    if (typeof window.openai?.setWidgetState !== "function") return;
    const cases = Object.fromEntries(Object.entries(states).map(([id, s]) => [id, { ...s }]));
    const saved = {
      modelContent: { taskId: caseId, view, role: state().role, callId: state().call, goal: state().goal },
      privateContent: { taskEngineReview: { revision: 1, caseId, view, language, theme, cases } }
    };
    Promise.resolve(window.openai.setWidgetState(saved)).catch(() => {});
  }

  function renderPhoto(container, large = false) {
    const data = sample();
    const selected = state().role;
    const img = el("img");
    img.src = data.scene;
    img.alt = t(data.title + "的输入场景","Source scene for " + data.title);
    container.replaceChildren(img);
    for (const [key, box] of Object.entries(data.boxes)) {
      if (selected && key !== selected) continue;
      const outline = large ? el("span", "te-box") : button("role", key, "te-box");
      if (!large) {
        outline.dataset.focus = "box/" + key;
        outline.setAttribute("aria-label", t("定位" + data.roles[key] + "的相关动作","Locate actions for " + data.roles[key]));
        outline.setAttribute("aria-pressed", String(key === selected));
      }
      const [x0, y0, x1, y1] = box;
      Object.assign(outline.style, {
        left: x0 * 100 + "%", top: y0 * 100 + "%",
        width: (x1 - x0) * 100 + "%", height: (y1 - y0) * 100 + "%"
      });
      if (key === selected || large) {
        outline.classList.add("is-focused");
        outline.append(el("span", "te-box-name", data.roles[key]));
      }
      container.append(outline);
    }
  }

  function renderRoles() {
    const data = sample();
    const selected = state().role;
    const chips = Object.entries(data.roles).map(([key, label]) => {
      const chip = button("role", key, "te-role", label);
      chip.setAttribute("aria-pressed", String(selected === key));
      return chip;
    });
    ui("roles").replaceChildren(...chips);
    const needsBox = !!selected && !data.boxes[selected];
    ui("role-note").hidden = !needsBox;
    ui("role-note").textContent = needsBox ? t(data.roles[selected] + "尚无图像标注框。","No source annotation for " + data.roles[selected] + ".") : "";
    renderPhoto(ui("image"));
  }

  function appendEvidence(container, uid) {
    const data = sample();
    const action = data.actions[uid];
    const direct = [...new Set(action.checks.flatMap(check => check.quotes))];
    const source = direct.length ? direct : data.stages[stageIndex(uid)].quotes;
    if (source.length) {
      container.append(el("h3", "", direct.length ? t("对应原文","Source wording (Chinese)") : t("所属阶段原文","Stage wording (Chinese)")));
      for (const quote of source) {
        const block = el("blockquote", "te-quote", "“" + quote + "”");
        block.lang = "zh-CN";
        container.append(block);
      }
    }
    if (action.checks.length) {
      container.append(el("h3", "", t("本步检查条件","Checks for this step")));
      const checks = el("ul", "te-checks");
      for (const check of action.checks) {
        const li = el("li", check.goalId && state().goal === check.goalId ? "te-hit" : "");
        const scope = check.scopes.map(value => value === "goal" ? t("完成条件","completion criterion") : t("里程碑","milestone")).join(t("、",", "));
        li.append(el("span", "", check.label), el("small", "", phaseName(check.phase) + " · " + scope));
        checks.append(li);
      }
      container.append(checks);
    }
  }

  function renderStages() {
    const data = sample(), s = state();
    const sections = data.stages.map((stage, index) => {
      const group = el("section", "te-stage");
      const isOpen = s.openStage === index;
      group.dataset.open = String(isOpen);
      group.dataset.related = String(stage.calls.some(directlyRelated));
      const toggle = button("stage", String(index), "te-stage-toggle");
      const listId = "te-phase-" + index;
      toggle.setAttribute("aria-expanded", String(isOpen));
      toggle.setAttribute("aria-controls", listId);
      const first = data.actions[stage.calls[0]].number;
      const last = data.actions[stage.calls[stage.calls.length - 1]].number;
      const range = first === last ? t("第 " + first + " 步","Step " + first) : t("第 " + first + "–" + last + " 步","Steps " + first + "–" + last);
      const chevron = el("span", "te-chevron");
      chevron.append(icon("chevron-down"));
      toggle.append(el("span", "te-stage-no", String(index + 1)), el("span", "te-stage-title", stage.label),
        el("span", "te-range", range), chevron);
      const list = el("ol", "te-steps");
      list.id = listId;
      list.start = first;
      list.hidden = !isOpen;
      for (const uid of stage.calls) {
        const item = data.actions[uid];
        const li = el("li");
        const chosen = uid === s.call;
        const control = button("call", uid, "te-step");
        control.dataset.related = String(directlyRelated(uid));
        control.setAttribute("aria-pressed", String(chosen));
        control.setAttribute("aria-controls", "te-node-detail");
        control.setAttribute("aria-label", t("第 " + item.number + " 步，","Step " + item.number + ", ") + item.label);
        control.append(el("span", "te-number", String(item.number).padStart(2, "0")), el("span", "te-action-label", item.label));
        li.append(control);
        list.append(li);
      }
      group.append(toggle, list);
      return group;
    });
    ui("stages").replaceChildren(...sections);
  }

  function renderGoals() {
    const data = sample();
    const rows = data.goals.map(goal => {
      const li = el("li");
      const link = button("goal", goal.id, "te-goal-link");
      link.setAttribute("aria-pressed", String(goal.id === state().goal));
      const phase = goal.phase === "terminal" ? "" : " · " + phaseName(goal.phase);
      const number = data.actions[goal.call].number;
      const jump = t("第 " + number + " 步","Step " + number) + phase;
      link.append(el("span", "te-goal-text", goal.label), el("span", "te-locate", jump + " →"));
      li.append(link);
      return li;
    });
    ui("goals").replaceChildren(...rows);
  }

  const svgNS = "http://www.w3.org/2000/svg";
  function svg(tag, attrs, text) {
    const item = document.createElementNS(svgNS, tag);
    for (const [key, value] of Object.entries(attrs)) item.setAttribute(key, String(value));
    if (text !== undefined) item.textContent = text;
    return item;
  }

  function resourceLane(node) {
    const r = node.call.resources;
    if ((r.source && r.destination) || (r.left && r.right)) return "shared";
    return r.primary || "unassigned";
  }

  function laneLabel(key) {
    if (key === "shared") return t("交接 / 协同", "Shared");
    if (key === "unassigned") return t("机械臂待分配", "Arm unassigned");
    return ["left","right"].includes(key) ? armName(key) : key;
  }

  function laneNodeText(node, compact) {
    const call = node.call, r = call.resources;
    const args = call.arguments || call;
    const object = sample().roles[args.object];
    const name = language === "en" ? object?.toLowerCase() : object;
    const short = {pick:t("抓取","Pick "),place:t("放下","Place "),hand_over:t("交接","Pass "),"simulation.coordinated_transport":t("搬运","Carry ")}[callKind(node)];
    const number = sample().actions[node.id].number;
    const direction = r.source && r.destination ?
      (compact ? [r.source,r.destination].map(side => side === "left" ? t("左","L") : t("右","R")).join(" → ") : armName(r.source) + " → " + armName(r.destination)) :
      r.left && r.right ? t("双臂同时","Both arms") : "";
    return [short && name ? short + name : sample().actions[node.id].label, [compact ? String(number).padStart(2,"0") : node.id,direction].filter(Boolean).join(" · ")];
  }

  function graphLayout(width) {
    const nodes = sample().graph.nodes;
    const used = [...new Set(nodes.map(resourceLane))];
    const assigned = used.some(k => k !== "unassigned");
    const tracks = assigned ? ["left","shared","right",...used.filter(k => !["left","shared","right"].includes(k))] : ["unassigned"];
    const span = width / tracks.length;
    const header = 34;
    const lanes = tracks.map((key,i) => ({key,x:i*span,width:span}));
    if (assigned) {
      const pad = width < 390 ? 3 : 6, w = span - 2 * pad;
      const baseHeight = language === "en" ? (w < 120 ? 90 : w < 225 ? 72 : 54) : w < 104 ? 72 : 54;
      const gap = 18, positions = new Map();
      let y = header + 5;
      for (const n of nodes) {
        const charsPerLine = Math.max(1, Math.floor((w - 16) / 7.5));
        const h = baseHeight + 18 * Math.ceil(callKind(n).length / charsPerLine);
        positions.set(n.id, {x: tracks.indexOf(resourceLane(n))*span + pad, y, w, h});
        y += h + gap;
      }
      return {width,height:y-gap+5,positions,lanes,assigned};
    }
    const gap = 24, pad = 2;
    const cols = Math.max(1, Math.min(3, Math.floor((width - 2 * pad + gap) / (228 + gap))));
    const w = (width - 2 * pad - gap * (cols - 1)) / cols;
    const h = (language === "en" ? (w < 265 ? 120 : 100) : (w < 248 ? 96 : 76)) + 24;
    const positions = new Map();
    nodes.forEach((n, i) => {
      const row = Math.floor(i / cols);
      const col = row % 2 ? cols - 1 - i % cols : i % cols;
      positions.set(n.id, { x: pad + col * (w + gap), y: header + pad + row * (h + gap), w, h });
    });
    const rows = Math.ceil(nodes.length / cols);
    return { width, height: header + rows * h + (rows - 1) * gap + pad * 2, positions, lanes, assigned };
  }

  function laneBands(layout) {
    const bands = svg("g", {class:"te-lane-bands"});
    for (const lane of layout.lanes) {
      const g = svg("g", {"data-lane":lane.key});
      g.append(svg("rect", {x:lane.x+1,y:0,width:Math.max(1,lane.width-2),height:layout.height,rx:5,class:"te-lane-bg"}));
      g.append(svg("text", {x:lane.x+lane.width/2,y:21,"text-anchor":"middle",class:"te-lane-label"},laneLabel(lane.key)));
      bands.append(g);
    }
    return bands;
  }

  function wires(layout, markerId, selected = null) {
    const group = svg("g", {});
    const defs = svg("defs", {});
    const marker = svg("marker", { id: markerId, viewBox: "0 0 8 8", refX: 7, refY: 4, markerWidth: 6, markerHeight: 6, orient: "auto" });
    marker.append(svg("path", { d: "M0 0 L8 4 L0 8 Z", class: "te-arrow" }));
    defs.append(marker);
    group.append(defs);
    for (const n of sample().graph.nodes) {
      const target = layout.positions.get(n.id);
      for (const dep of n.depends_on) {
        const base = layout.positions.get(dep);
        let x1, x2, y1, y2;
        if (base.y === target.y) {
          const forward = target.x > base.x;
          x1 = forward ? base.x + base.w : base.x;
          x2 = forward ? target.x - 2 : target.x + target.w + 2;
          y1 = y2 = base.y + base.h / 2;
        } else {
          x1 = base.x + base.w / 2;
          x2 = target.x + target.w / 2;
          y1 = base.y + base.h;
          y2 = target.y - 2;
        }
        const edge = {class: n.id === selected ? "te-wire te-incoming" : "te-wire",
          "data-from": dep, "data-to": n.id, "marker-end": "url(#" + markerId + ")"};
        if (layout.assigned && x1 !== x2 && y1 !== y2) {
          const mid = (y1+y2)/2;
          group.append(svg("path", {...edge,d:"M"+x1+" "+y1+" V"+mid+" H"+x2+" V"+y2}));
        } else group.append(svg("line", {...edge,x1,x2,y1,y2}));
      }
    }
    return group;
  }

  const callKind = n => n.call.call_id || n.call.kind;

  function renderBoard() {
    if (view !== "engineering") return;
    const board = ui("graph");
    const width = Math.floor(board.getBoundingClientRect().width);
    if (!width) return;
    lastBoardWidth = width;
    const data = sample(), layout = graphLayout(width);
    board.style.height = layout.height + "px";
    const lines = svg("svg", { class: "te-wires", viewBox: "0 0 " + width + " " + layout.height });
    lines.setAttribute("role","img");
    lines.setAttribute("aria-label",layout.lanes.map(l => laneLabel(l.key)).join(", "));
    lines.append(laneBands(layout), wires(layout, "te-edge-arrow", state().call));
    const active = state().call;
    const controls = data.graph.nodes.map(n => {
      const item = data.actions[n.id], pos = layout.positions.get(n.id);
      const control = button("node", n.id, "te-graph-node");
      control.setAttribute("aria-pressed", String(n.id === active));
      control.setAttribute("aria-controls", "te-node-detail");
      control.dataset.lane = resourceLane(n);
      control.setAttribute("aria-label", n.id + " · " + callKind(n) + " · " + laneLabel(control.dataset.lane) + " · " + item.label);
      control.dataset.related = String(directlyRelated(n.id));
      Object.assign(control.style, { left: pos.x + "px", top: pos.y + "px", width: pos.w + "px", height: pos.h + "px" });
      const [title, sub] = layout.assigned ? laneNodeText(n,pos.w < 155) : [item.label,n.id];
      control.append(el("span", "te-graph-name", title), el("code", "te-call-name", callKind(n)), el("span", "te-graph-code", sub));
      return control;
    });
    board.replaceChildren(lines, ...controls);
  }

  function renderActionDetail() {
    const data = sample(), s = state(), panel = ui("node-detail"), uid = s.call;
    const key = [caseId,uid,s.goal,language].join("/");
    if (panel.dataset.detailKey === key) return;
    const preserveEngineering = panel.dataset.record === caseId + "/" + uid && !!panel.querySelector(".te-raw[open]");
    panel.dataset.detailKey = key;
    panel.dataset.record = caseId + "/" + uid;
    panel.hidden = !uid;
    panel.replaceChildren();
    if (!uid) return;
    const n = forCall(uid);
    const action = data.actions[uid];
    const heading = el("div", "te-heading");
    heading.append(el("h2", "", action.label), el("span", "te-meta", t("第 " + action.number + " 步详情","Step " + action.number + " details")));
    const metadata = el("div", "te-tech-links");
    const res = n.call.resources;
    const arm = res.primary ? armName(res.primary) : res.source ? armName(res.source) + " → " + armName(res.destination) :
      res.left && res.right ? t("双臂协同","both arms") : t("待分配","unassigned");
    for (const dep of n.depends_on) {
      const index = data.actions[dep].number;
      metadata.append(button("dependency",dep,"te-text-button",t("前置步骤 " + index,"Prerequisite: step " + index) + " · " + dep));
    }
    metadata.append(el("code", "", n.id), el("span", "", t("机械臂　","Arm · ") + arm));
    const info = el("div", "te-step-info");
    appendEvidence(info, uid);
    const raw = el("details", "te-raw");
    raw.open = preserveEngineering;
    raw.append(el("summary", "", t("工程信息","Engineering information")), metadata);
    info.append(raw);
    if (action.binding) {
      const declaration = el("details", "te-raw");
      declaration.append(el("summary", "", t("该调用的绑定声明","Binding declaration")), el("pre", "", JSON.stringify(action.binding, null, 2)));
      raw.append(declaration);
    }
    const semantic = el("details", "te-semantic");
    const summary = el("summary");
    summary.append(document.createTextNode("Semantic Call　"), el("code","te-call-name",callKind(n)));
    semantic.append(summary, el("pre","",JSON.stringify(n.call,null,2)));
    panel.append(heading, semantic, info);
  }

  function render() {
    preferences();
    const data = sample(), s = state();
    ui("case").value = caseId;
    ui("title").textContent = data.title;
    ui("coverage").textContent = data.coverage === "covered" ? t("通过","Passed") : t("待核对","Pending");
    ui("scene-status").textContent = data.stage === "ready_for_qualification" ?
      Object.keys(data.boxes).length + "/" + Object.keys(data.roles).length + t(" 已标注 · 待资格检查"," annotated · qualification pending") : t("仅计划 · 尚未绑定","Plan only · unbound");
    ui("instruction").textContent = t(data.graph.instruction,data.instructionEn);
    ui("review-view").setAttribute("aria-pressed", String(view === "review"));
    ui("engine-view").setAttribute("aria-pressed", String(view === "engineering"));
    ui("stages").hidden = view !== "review";
    ui("graph").hidden = view !== "engineering";
    const nodes = data.graph.nodes, count = nodes.filter(n => directlyRelated(n.id)).length;
    ui("flow-meta").textContent = s.role ? t(data.roles[s.role] + "关联 " + count + " 个动作", data.roles[s.role] + " · " + count + (count === 1 ? " related action" : " related actions")) :
      data.stages.length + t(" 个阶段 · "," stages · ") + nodes.length + t(" 个动作"," actions");
    if (view === "review") renderStages();
    else renderBoard();
    renderRoles();
    renderGoals();
    renderActionDetail();
    refreshIcons();
  }

  function update(focusKey, locate = false) {
    render();
    if (focusKey) {
      const control = [...root.querySelectorAll("button[data-focus]")].find(b => b.dataset.focus === focusKey && b.getClientRects().length);
      if (control) {
        control.focus({ preventScroll: true });
        if (locate) control.scrollIntoView({ block: "nearest", inline: "nearest" });
      }
    }
    save();
  }

  function chooseCall(uid, goal = null) {
    const s = state();
    if (s.role && !directlyRelated(uid)) s.role = null;
    s.call = uid;
    s.inferred = false;
    s.goal = goal;
    s.openStage = stageIndex(uid);
  }

  function toggleRole(uid) {
    const s = state();
    s.role = s.role === uid ? null : uid;
    if (s.inferred) { s.call = null; s.inferred = false; }
    if (!s.role) return;
    if (s.call && !directlyRelated(s.call)) {
      s.call = null;
      s.goal = null;
    }
    if (!sample().stages[s.openStage]?.calls.some(directlyRelated)) {
      s.openStage = sample().stages.findIndex(stage => stage.calls.some(directlyRelated));
    }
    const matches = sample().graph.nodes.filter(n => directlyRelated(n.id));
    if (!s.call && matches.length === 1) {
      s.call = matches[0].id;
      s.inferred = true;
      s.openStage = stageIndex(s.call);
    }
  }

  function svgExport() {
    const data = sample(), layout = graphLayout(960), header = 58;
    const diagramTitle = data.title + t(" · 调用依赖"," · Call dependencies");
    const out = svg("svg", { viewBox: "0 0 984 " + (layout.height + header + 16), width: 984, height: layout.height + header + 16, role: "img", "aria-label":diagramTitle });
    out.append(svg("title", {}, diagramTitle));
    out.append(svg("style", {}, "text{font-family:system-ui,sans-serif;fill:#19323c}.te-wire{stroke:#60757c;stroke-width:1.5}.te-arrow{fill:#60757c}.node{fill:#f4f9f8;stroke:#b8ccca}.code{font-family:monospace;fill:#455c65}"));
    out.append(svg("rect", { width: "100%", height: "100%", fill: "#fff" }));
    out.append(svg("text", { x: 14, y: 34, "font-size": 22 }, data.title + " · " + caseId));
    const board = svg("g", { transform: "translate(12," + header + ")" });
    board.append(svg("style", {}, ".te-lane-bg{fill:#f0f3f5}[data-lane=left] .te-lane-bg{fill:#e9f1fc}[data-lane=right] .te-lane-bg{fill:#f7efe2}[data-lane=shared] .te-lane-bg{fill:#e5f3ef}.te-lane-label{font-size:14px;font-weight:600}"));
    board.append(laneBands(layout),wires(layout, "dependency-tip"));
    for (const n of data.graph.nodes) {
      const p = layout.positions.get(n.id);
      const g = svg("g", { id: n.id });
      const [title,sub] = layout.assigned ? laneNodeText(n,false) : [data.actions[n.id].label,n.id];
      const lines = language === "en" ? title.match(/.{1,35}(?:\s|$)/g).map(s=>s.trim()) : [title];
      g.append(svg("rect", { class: "node", x: p.x, y: p.y, width: p.w, height: p.h, rx: 7 }));
      lines.forEach((line,i)=>g.append(svg("text", { x:p.x+12, y:p.y+25+18*i, "font-size":15 }, line)));
      g.append(svg("text", {class:"code", x:p.x+12, y:p.y+p.h-31, "font-size":12}, callKind(n)));
      g.append(svg("text", { class: "code", x: p.x + 12, y: p.y + p.h - 13, "font-size": 12 }, sub));
      board.append(g);
    }
    out.append(board);
    return new XMLSerializer().serializeToString(out);
  }

  function showSpec() {
    const data = sample(), spec = data.spec, body = ui("spec-body");
    body.replaceChildren(el("p", "te-meta", spec.task_id + " · " + spec.schema_version));
    body.append(el("h3", "", t("任务指令","Task instruction")), el("p", "", t(spec.inputs.instruction, data.instructionEn)));
    body.append(el("h3", "", t("任务对象","Task objects")), el("p", "", spec.configuration.roles.map(r => data.roles[r.id]).join(t("、", ", "))));
    const milestones = el("ol");
    for (const row of spec.objectives.milestones) {
      const names = data.milestoneLabels[row.id].map(s => language === "en" ? label(s) : s);
      const item = el("li");
      item.append(el("code", "", row.id), document.createTextNode(names.join(t("、", ", "))));
      milestones.append(item);
    }
    body.append(el("h3", "", t("里程碑","Milestones")), milestones);
    const goals = el("ul");
    for (const goal of data.goals) goals.append(el("li", "", goal.label));
    body.append(el("h3", "", t("完成条件","Completion criteria")), goals);
    const raw = el("details", "te-raw");
    raw.append(el("summary", "", t("完整规范","Full specification") + " · task_spec_v1.json"), el("pre", "", JSON.stringify(spec, null, 2)));
    body.append(raw);
    ui("spec-dialog").showModal();
  }

  function setExport() {
    const format = ui("format").value;
    const json = format !== "svg";
    const data = sample();
    ui("export-text").value = json ? JSON.stringify(format === "spec" ? data.spec : data.graph, null, 2) : svgExport();
    ui("copy").textContent = t("复制 ","Copy ") + (json ? "JSON" : "SVG");
    ui("copy-state").textContent = format === "spec" ? caseId + "/task_spec_v1.json" : caseId + (json ? ".semantic-graph.json" : ".dependencies.svg");
  }

  async function copyExport() {
    const field = ui("export-text");
    field.focus();
    field.select();
    let copied = false;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(field.value);
        copied = true;
      }
    } catch {}
    if (!copied) {
      try { copied = document.execCommand("copy"); } catch {}
    }
    ui("copy-state").textContent = copied ? t("已复制","Copied") : t("内容已选中，可使用系统复制。","Text selected. Use the system copy command.");
  }

  ui("language").addEventListener("change", event => { language = event.target.value; update(); });
  ui("theme").addEventListener("change", event => { theme = event.target.value; update(); });
  ui("case").addEventListener("change", event => {
    caseId = event.target.value;
    update();
  });
  ui("format").addEventListener("change", setExport);
  for (const dialog of root.querySelectorAll("dialog")) {
    dialog.addEventListener("click", event => {
      if (event.target !== dialog) return;
      const b = dialog.getBoundingClientRect();
      if (event.clientX < b.left || event.clientX > b.right || event.clientY < b.top || event.clientY > b.bottom) dialog.close();
    });
  }
  root.addEventListener("click", event => {
    const control = event.target.closest("button[data-command]");
    if (!control || !root.contains(control)) return;
    const { command, key, focus } = control.dataset;
    const s = state();
    switch (command) {
      case "view":
        view = key;
        if (view === "review" && s.call) s.openStage = stageIndex(s.call);
        update();
        break;
      case "stage":
        s.openStage = s.openStage === Number(key) ? -1 : Number(key);
        update(focus);
        break;
      case "role":
        toggleRole(key);
        update(focus);
        break;
      case "call":
      case "node":
        chooseCall(key);
        update(focus);
        break;
      case "dependency":
        chooseCall(key);
        update((view === "review" ? "call/" : "node/") + key, true);
        break;
      case "goal": {
        const goal = sample().goals.find(g => g.id === key);
        chooseCall(goal.call, goal.id);
        update((view === "review" ? "call/" : "node/") + goal.call, true);
        break;
      }
      case "image":
        renderPhoto(ui("large-image"), true);
        ui("image-dialog").showModal();
        break;
      case "export": {
        setExport();
        const dialog = ui("export-dialog");
        dialog.showModal();
        // Focusing Close alone can leave Copy below the host viewport.
        dialog.scrollIntoView({ block: "center", inline: "nearest" });
        break;
      }
      case "spec":
        showSpec();
        break;
      case "copy":
        copyExport();
        break;
      case "close-dialog":
        control.closest("dialog").close();
        break;
    }
  });
  new ResizeObserver(entries => {
    if (view === "engineering" && Math.floor(entries[0].contentRect.width) !== lastBoardWidth) renderBoard();
  }).observe(ui("graph"));

  restore(window.openai?.widgetState);
  render();
  window.addEventListener("openai:set_globals", event => {
    if (restore(event.detail?.globals?.widgetState)) render();
  });
})();
